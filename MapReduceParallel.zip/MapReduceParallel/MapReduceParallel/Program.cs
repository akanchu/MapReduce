﻿var parallelFunctions = new MapReduceClass();
var functionsToRunInMNR = parallelFunctions.GetFunctions();

try
{
    var results = await parallelFunctions.ProcessMapNReduceAsync(2, functionsToRunInMNR, 1000);
    foreach (var result in results)
    {
        Console.WriteLine(result);
    }
}
catch (TimeoutException ex)
{
    Console.WriteLine(ex.Message);
}
