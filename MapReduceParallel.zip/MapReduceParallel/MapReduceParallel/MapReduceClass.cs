﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

public class MapReduceClass
{
    public delegate Task<object> WorkFunction();

    public async Task<List<object>> ProcessMapNReduceAsync(
        int maxDegreeOfParallelism,
        List<WorkFunction> functions,
        int timeoutMs)
    {
        if (maxDegreeOfParallelism <= 0)
            throw new ArgumentException("maxDegreeOfParallelism must be greater than 0");

        if (functions == null)
            throw new ArgumentNullException(nameof(functions));

        if (timeoutMs <= 0)
            throw new ArgumentException("timeoutMs must be greater than 0");

        var results = new List<object>(new object[functions.Count]);
        var semaphore = new SemaphoreSlim(maxDegreeOfParallelism);
        var cts = new CancellationTokenSource(timeoutMs);

        var tasks = functions.Select(async (func, index) =>
        {
            try
            {
                await semaphore.WaitAsync(cts.Token);
                try
                {
                    var taskCts = CancellationTokenSource.CreateLinkedTokenSource(cts.Token);
                    taskCts.CancelAfter(timeoutMs);

                    var task = func();
                    if (await Task.WhenAny(task, Task.Delay(Timeout.Infinite, taskCts.Token)) == task)
                    {
                        results[index] = await task; 
                    }
                    else
                    {
                        results[index] = "Operation was canceled due to timeout.";
                    }
                }
                catch (Exception ex)
                {
                    results[index] = $"Error: {ex.Message}";
                }
                finally
                {
                    semaphore.Release();
                }
            }
            catch (OperationCanceledException) when (cts.Token.IsCancellationRequested)
            {
                results[index] = "Operation was canceled due to timeout.";
            }
        }).ToList();

        try
        {
            await Task.WhenAll(tasks);
        }
        catch (OperationCanceledException) when (cts.Token.IsCancellationRequested)
        {
            throw new TimeoutException("The operation has timed out.");
        }
        finally
        {
            cts.Dispose();
            semaphore.Dispose();
        }

        return results;
    }

    public List<WorkFunction> GetFunctions()
    {
        return new List<WorkFunction>
        {
            async () => {
                Console.WriteLine("Performing CPU-bound work");
                await Task.Delay(100); 
                return await Task.Run(() =>
                {
                    // CPU-bound computation
                    long result = 0;
                    for (long i = 0; i < 1_000_000; i++)
                    {
                        result += i;
                    }
                    return $"CPU-bound result: {result}";
                });
            },

            async () => {
                Console.WriteLine("Performing network-bound work");
                await Task.Delay(200); // Simulate network delay
                return "Network-bound result";
            },

            // Disk I/O bound work
            async () => {
                Console.WriteLine("Performing disk I/O bound work");
                var filePath = Path.GetTempFileName();
                await File.WriteAllTextAsync(filePath, "Temporary content");
                var content = await File.ReadAllTextAsync(filePath);
                File.Delete(filePath);
                return $"Disk I/O result: {content}";
            },
            //Some general functions 
                    async () =>
        {
            Console.WriteLine("In Sum Function Def");
            await Task.Delay(100);
            int num1 = 5;
            int num2 = 10;
            return await Sum(num1, num2);
        },
            async () =>
            {
                Console.WriteLine("In Subtract Def");
                await Task.Delay(200);
                int num1 = 50;
                int num2 = 10;
                return await Subtract(num1, num2);
            },
            async () =>
            {
                Console.WriteLine("In Multiply Def");
                await Task.Delay(300);
                int num1 = 5;
                int num2 = 10;
                return await Multiply(num1, num2);
            },
            async () =>
            {
                Console.WriteLine("In Divide Def");
                await Task.Delay(400);
                int num1 = 50;
                int num2 = 10;
                return await Divide(num1, num2);
            },
               async () => {
                Console.WriteLine("Performing function that may crash");
                await Task.Delay(300); // Simulate delay
                var random = new Random();
                if (random.Next(0, 2) == 0)
                {
                    throw new InvalidOperationException("Random failure");
                }
                return "Function completed successfully";
            }
        };       
    }

    public async Task<object> Sum(int num1, int num2)
    {
        Console.WriteLine("In Sum Function Call");
        return $"Sum - {num1} and {num2} is {num1 + num2}";
    }

    public async Task<object> Subtract(int num1, int num2)
    {
        Console.WriteLine("In Subtract Call");
        return $"Subtract - {num2} from {num1} is {num1 - num2}";
    }

    public async Task<object> Multiply(int num1, int num2)
    {
        Console.WriteLine("In Multiply Call");
        return $"Multiply - {num1} and {num2} is {num1 * num2}";
    }

    public async Task<object> Divide(int num1, int num2)
    {
        Console.WriteLine("In Divide Call");
        if (num2 == 0)
        {
            return "Error: Division by zero";
        }
        return $"Divide - {num1} by {num2} is {num1 / num2}";
    }
}